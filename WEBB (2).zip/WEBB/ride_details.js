var currentRideId = null;


// =========================================
// 1. Get ride ID from URL
// =========================================

var urlParams =
    new URLSearchParams(window.location.search);

currentRideId =
    urlParams.get("id");


// =========================================
// 2. Load ride details
// =========================================

document.addEventListener("DOMContentLoaded", function () {

    if (!currentRideId) {

        alert("Ride ID not found.");

        return;
    }


    fetch(
        "ride_details.php?id=" +
        encodeURIComponent(currentRideId)
    )

        .then(function (response) {

            return response.json();

        })

        .then(function (data) {

            // =========================================
            // Backend error
            // =========================================

            if (!data.success) {

                alert(data.message);

                return;
            }


            var ride =
                data.ride;


            // =========================================
            // Route
            // =========================================

            var routeBox =
                document.querySelector(".items.blue");

            if (routeBox) {

                var routeParagraphs =
                    routeBox.querySelectorAll("p");


                if (routeParagraphs[0]) {

                    routeParagraphs[0].textContent =
                        "Pickup: " +
                        (
                            ride.from_location ||
                            "Not specified"
                        );
                }


                if (routeParagraphs[1]) {

                    routeParagraphs[1].textContent =
                        "Destination: " +
                        (
                            ride.to_location ||
                            "Not specified"
                        );
                }
            }


            // =========================================
            // All item boxes
            // =========================================

            var items =
                document.querySelectorAll(".items");


            // =========================================
            // Pickup checkpoints
            // =========================================

            if (items[1]) {

                var pickupText =
                    ride.pickup_checkpoint;

                items[1]
                    .querySelector("p")
                    .textContent =
                    pickupText ||
                    "Not specified";
            }


            // =========================================
            // Drop checkpoints
            // =========================================

            if (items[2]) {

                var dropText =
                    ride.drop_checkpoint;

                items[2]
                    .querySelector("p")
                    .textContent =
                    dropText ||
                    "Not specified";
            }


            // =========================================
            // Schedule and seats
            // =========================================

            if (items[3]) {

                var date =
                    ride.ride_date ||
                    "Not specified";

                var time =
                    ride.ride_time ||
                    "Not specified";


                items[3]
                    .querySelector("p")
                    .textContent =
                    date +
                    " • " +
                    time;


                var seatParagraph =
                    items[3]
                        .querySelectorAll("p")[1];


                if (seatParagraph) {

                    seatParagraph.textContent =
                        ride.available_seats +
                        " seats available";
                }
            }


            // =========================================
            // Driver name
            // =========================================

            var driverName =
                document.querySelector(
                    ".driver-info h2"
                );


            if (driverName) {

                driverName.textContent =
                    ride.driver_name ||
                    "Unknown driver";
            }


            // =========================================
            // Vehicle information
            // =========================================

            var driverInfo =
                document.querySelector(
                    ".driver-info"
                );


            if (driverInfo) {

                var paragraphs =
                    driverInfo.querySelectorAll("p");


                /*
                 * First p = rating
                 * Second p = vehicle information
                 */

                if (paragraphs.length > 1) {

                    var vehicleText =
                        ride.vehicle_type ||
                        "Vehicle information not available";


                    if (ride.female_only == 1) {

                        vehicleText +=
                            " • Female-only ride";
                    }


                    paragraphs[1].textContent =
                        vehicleText;
                }
            }

        })

        .catch(function (error) {

            console.log("Error:", error);

            alert(
                "Something went wrong while loading ride details."
            );

        });

});


// =========================================
// 3. Book Ride
// =========================================

function bookRide() {

    if (!currentRideId) {

        alert("Ride ID not found.");

        return;
    }


    // =========================================
    // Get selected tip
    // =========================================

    var tipAmount = 0;

    var selectedTip =
        sessionStorage.getItem("rideNestTip");


    if (selectedTip !== null) {

        tipAmount =
            Number(selectedTip);

    }


    // =========================================
    // Validate tip
    // =========================================

    if (
        isNaN(tipAmount) ||
        tipAmount < 0
    ) {

        tipAmount = 0;

    }


    tipAmount =
        Math.round(
            tipAmount * 100
        ) / 100;


    // =========================================
    // Booking confirmation
    // =========================================

    var confirmMessage =
        "Confirm booking?";


    if (tipAmount > 0) {

        confirmMessage +=
            "\n\nExtra Tip: ৳" +
            tipAmount.toFixed(2);

    }


    var confirmBooking =
        confirm(confirmMessage);


    if (!confirmBooking) {

        return;
    }


    // =========================================
    // Form Data
    // =========================================

    var formData =
        new FormData();


    formData.append(
        "ride_id",
        currentRideId
    );


    // Currently one seat is booked
    formData.append(
        "seats",
        1
    );


    // Send tip
    formData.append(
        "tip_amount",
        tipAmount
    );


    // =========================================
    // Send booking request
    // =========================================

    fetch(
        "book_ride.php",
        {
            method: "POST",
            body: formData
        }
    )

        .then(function (response) {

            return response.json();

        })

        .then(function (data) {

            if (data.success) {

                // Remove saved tip
                sessionStorage.removeItem(
                    "rideNestTip"
                );


                alert(data.message);


                window.location.href =
                    "My Rides.html";

            }

            else {

                alert(data.message);

            }

        })

        .catch(function (error) {

            console.log(error);

            alert(
                "Something went wrong while booking."
            );

        });

}