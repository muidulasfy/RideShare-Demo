<?php

session_start();

include "db.php";

header("Content-Type: application/json");


// ==========================================
// CHECK LOGIN
// ==========================================

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);

    exit;
}


// ==========================================
// USER ID
// ==========================================

$user_id =
    (int) $_SESSION['user_id'];


// ==========================================
// GET BOOKINGS
// ==========================================

$sql = $conn->prepare("
    SELECT

        b.id AS booking_id,
        b.ride_id,
        b.seats_booked,
        b.booking_status,
        b.booked_at,
        b.tip_amount,

        r.from_location,
        r.to_location,
        r.ride_date,
        r.ride_time,
        r.vehicle_type,

        u.id AS driver_id,
        u.name AS driver_name,
        u.phone AS driver_phone

    FROM bookings b

    INNER JOIN rides r
        ON b.ride_id = r.id

    INNER JOIN users u
        ON r.driver_id = u.id

    WHERE b.user_id = ?

    ORDER BY
        r.ride_date ASC,
        r.ride_time ASC
");


if (!$sql) {

    error_log(
        "My Rides prepare failed: " .
        $conn->error
    );

    echo json_encode([
        "success" => false,
        "message" => "Unable to load bookings."
    ]);

    exit;
}


$sql->bind_param(
    "i",
    $user_id
);


if (!$sql->execute()) {

    error_log(
        "My Rides execute failed: " .
        $sql->error
    );

    echo json_encode([
        "success" => false,
        "message" => "Unable to load bookings."
    ]);

    $sql->close();
    $conn->close();

    exit;
}


// ==========================================
// GET RESULT
// ==========================================

$result =
    $sql->get_result();


$bookings = [];


// ==========================================
// STORE BOOKINGS
// ==========================================

while (
    $row =
    $result->fetch_assoc()
) {

    // Make sure tip is always numeric
    $row['tip_amount'] =
        (float) (
            $row['tip_amount'] ?? 0
        );


    $bookings[] =
        $row;
}


// ==========================================
// RESPONSE
// ==========================================

echo json_encode([
    "success" => true,
    "bookings" => $bookings
]);


// ==========================================
// CLOSE
// ==========================================

$sql->close();

$conn->close();

?>