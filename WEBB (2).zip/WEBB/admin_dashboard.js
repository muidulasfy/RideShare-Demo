function deleteUser(id) {

    var answer = confirm("Are you sure you want to delete this user?");

    if (!answer) {
        return;
    }

    fetch("admin_delete_user.php?id=" + id)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {

            if (data.success) {
                alert("User deleted.");
                location.reload();
            } else {
                alert(data.message);
            }

        })
        .catch(function(error) {
            console.log(error);
            alert("Something went wrong.");
        });
}


function deleteRide(id) {

    var answer = confirm("Are you sure you want to delete this ride?");

    if (!answer) {
        return;
    }

    fetch("admin_delete_ride.php?id=" + id)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {

            if (data.success) {
                alert("Ride deleted.");
                location.reload();
            } else {
                alert(data.message);
            }

        })
        .catch(function(error) {
            console.log(error);
            alert("Something went wrong.");
        });
}