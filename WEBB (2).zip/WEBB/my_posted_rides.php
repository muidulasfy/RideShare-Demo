<?php

session_start();
include "db.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);
    exit;
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== "driver") {
    echo json_encode([
        "success" => false,
        "message" => "Only drivers can view posted rides."
    ]);
    exit;
}

$driver_id = (int) $_SESSION['user_id'];

$status = $_GET['status'] ?? 'upcoming';

if (!in_array($status, ['upcoming', 'completed', 'cancelled'], true)) {
    $status = 'upcoming';
}

/*
 * The project has used both price and price_per_seat in older versions.
 * The current Find Ride flow uses price. This check keeps this page
 * compatible with either existing database version.
 */
$priceColumn = "price";

$priceCheck = $conn->query("SHOW COLUMNS FROM rides LIKE 'price'");
if (!$priceCheck || $priceCheck->num_rows === 0) {
    $legacyPriceCheck = $conn->query("SHOW COLUMNS FROM rides LIKE 'price_per_seat'");
    if ($legacyPriceCheck && $legacyPriceCheck->num_rows > 0) {
        $priceColumn = "price_per_seat";
    }
}

if ($status === 'upcoming') {

    $sql = "
        SELECT
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn AS price_per_seat,
            r.female_only,
            r.recurring,
            r.status,

            COALESCE(
                SUM(
                    CASE
                        WHEN b.booking_status = 'confirmed'
                        THEN b.seats_booked
                        ELSE 0
                    END
                ),
                0
            ) AS booked_seats

        FROM rides r

        LEFT JOIN bookings b
            ON r.id = b.ride_id

        WHERE r.driver_id = ?
          AND r.status != 'cancelled'
          AND TIMESTAMP(r.ride_date, r.ride_time) >= NOW()

        GROUP BY
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn,
            r.female_only,
            r.recurring,
            r.status

        ORDER BY r.ride_date ASC, r.ride_time ASC
    ";

} elseif ($status === 'completed') {

    $sql = "
        SELECT
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn AS price_per_seat,
            r.female_only,
            r.recurring,
            r.status,

            COALESCE(
                SUM(
                    CASE
                        WHEN b.booking_status = 'confirmed'
                        THEN b.seats_booked
                        ELSE 0
                    END
                ),
                0
            ) AS booked_seats

        FROM rides r

        LEFT JOIN bookings b
            ON r.id = b.ride_id

        WHERE r.driver_id = ?
          AND r.status != 'cancelled'
          AND TIMESTAMP(r.ride_date, r.ride_time) < NOW()

        GROUP BY
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn,
            r.female_only,
            r.recurring,
            r.status

        ORDER BY r.ride_date DESC, r.ride_time DESC
    ";

} else {

    $sql = "
        SELECT
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn AS price_per_seat,
            r.female_only,
            r.recurring,
            r.status,

            COALESCE(
                SUM(
                    CASE
                        WHEN b.booking_status = 'confirmed'
                        THEN b.seats_booked
                        ELSE 0
                    END
                ),
                0
            ) AS booked_seats

        FROM rides r

        LEFT JOIN bookings b
            ON r.id = b.ride_id

        WHERE r.driver_id = ?
          AND r.status = 'cancelled'

        GROUP BY
            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.$priceColumn,
            r.female_only,
            r.recurring,
            r.status

        ORDER BY r.ride_date DESC, r.ride_time DESC
    ";
}

$stmt = $conn->prepare($sql);

if (!$stmt) {
    error_log("My Posted Rides prepare failed: " . $conn->error);

    echo json_encode([
        "success" => false,
        "message" => "Unable to load rides right now."
    ]);
    exit;
}

$stmt->bind_param("i", $driver_id);

if (!$stmt->execute()) {
    error_log("My Posted Rides execute failed: " . $stmt->error);

    echo json_encode([
        "success" => false,
        "message" => "Unable to load rides right now."
    ]);
    exit;
}

$result = $stmt->get_result();
$rides = [];

while ($row = $result->fetch_assoc()) {
    $rides[] = $row;
}

echo json_encode([
    "success" => true,
    "rides" => $rides
]);

$stmt->close();
$conn->close();
?>
