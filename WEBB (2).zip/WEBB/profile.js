document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadProfile();

    }
);



// ==========================================
// LOAD PROFILE
// ==========================================

function loadProfile() {

    fetch("profile.php")

    .then(function (response) {

        return response.json();

    })

    .then(function (data) {


        if (!data.success) {

            alert(
                data.message ||
                "Unable to load profile."
            );

            return;

        }


        var user =
            data.user;

        var stats =
            data.stats;

        var driver =
            data.driver;

        var rides =
            data.rides || [];



        // ==================================
        // NAME
        // ==================================

        var name =
            user.name || "User";


        document.getElementById(
            "userGreeting"
        ).innerText =

            getGreeting()
            + ", "
            + name
            + " 👋";



        // ==================================
        // PHONE
        // ==================================

        document.getElementById(
            "userPhone"
        ).innerText =

            user.phone ||
            "No phone number";



        // ==================================
        // PROFILE ICON
        // ==================================

        var profileIcon =
            document.querySelector(
                ".profile-icon"
            );


        if (profileIcon) {

            profileIcon.innerText =
                getInitial(name);

        }



        // ==================================
        // CHECK ROLE
        // ==================================

        if (
            String(user.role).toLowerCase()
            === "driver"
        ) {

            setupDriverProfile(
                user,
                driver,
                stats,
                rides
            );

        }

        else {

            setupUserProfile(
                user,
                stats,
                rides
            );

        }

    })

    .catch(function (error) {

        console.log(
            "Profile error:",
            error
        );


        document.getElementById(
            "userGreeting"
        ).innerText =
            "Unable to load profile";


        document.getElementById(
            "userPhone"
        ).innerText =
            "";

    });

}



// ==========================================
// USER PROFILE
// ==========================================

function setupUserProfile(
    user,
    stats,
    rides
) {


    // ==================================
    // STAT 1
    // ==================================

    document.getElementById(
        "statOne"
    ).innerText =
        stats.stat_one;


    document.getElementById(
        "statOneLabel"
    ).innerText =
        "Available rides";



    // ==================================
    // STAT 2
    // ==================================

    document.getElementById(
        "statTwo"
    ).innerText =
        stats.stat_two;


    document.getElementById(
        "statTwoLabel"
    ).innerText =
        "My bookings";



    // ==================================
    // RATING
    // ==================================

    document.getElementById(
        "averageRating"
    ).innerText =
        "No ratings yet";



    // ==================================
    // RANK
    // ==================================

    updateRank(
        stats.stat_two
    );



    // ==================================
    // DETAILS
    // ==================================

    var details =
        document.getElementById(
            "profileDetails"
        );


    details.innerText =
        "Department: "
        + (
            user.department ||
            "Not available"
        )
        + "  •  Student ID: "
        + (
            user.student_id ||
            "Not available"
        );



    // ==================================
    // TITLE
    // ==================================

    document.getElementById(
        "ridesTitle"
    ).innerText =
        "Recommended rides";



    // ==================================
    // RIDES
    // ==================================

    displayUserRides(
        rides
    );

}



// ==========================================
// DRIVER PROFILE
// ==========================================

function setupDriverProfile(
    user,
    driver,
    stats,
    rides
) {


    // ==================================
    // STAT 1
    // ==================================

    document.getElementById(
        "statOne"
    ).innerText =
        stats.stat_one;


    document.getElementById(
        "statOneLabel"
    ).innerText =
        "Posted rides";



    // ==================================
    // STAT 2
    // ==================================

    document.getElementById(
        "statTwo"
    ).innerText =
        stats.stat_two;


    document.getElementById(
        "statTwoLabel"
    ).innerText =
        "Confirmed passengers";



    // ==================================
    // RATING
    // ==================================

    document.getElementById(
        "averageRating"
    ).innerText =
        "No ratings yet";



    // ==================================
    // DRIVER RANK
    // ==================================

    updateDriverRank(
        stats.stat_two
    );



    // ==================================
    // VEHICLE DETAILS
    // ==================================

    var details =
        document.getElementById(
            "profileDetails"
        );


    if (driver) {

        details.innerText =

            "Vehicle: "
            + (
                driver.vehicle_model ||
                "Not available"
            )

            + "  •  Number: "
            + (
                driver.vehicle_number ||
                "Not available"
            )

            + "  •  License: "
            + (
                driver.license_number ||
                "Not available"
            );

    }

    else {

        details.innerText =
            "Driver information not available.";

    }



    // ==================================
    // TITLE
    // ==================================

    document.getElementById(
        "ridesTitle"
    ).innerText =
        "My Posted Rides";



    // ==================================
    // RIDES
    // ==================================

    displayDriverRides(
        rides
    );

}



// ==========================================
// USER RIDE CARDS
// ==========================================

function displayUserRides(
    rides
) {


    var container =
        document.getElementById(
            "rideContainer"
        );


    container.innerHTML = "";


    if (rides.length === 0) {

        var noRide =
            document.createElement(
                "p"
            );


        noRide.innerText =
            "No recommended rides available.";


        container.appendChild(
            noRide
        );


        return;

    }


    rides.forEach(
        function (ride, index) {


            var card =
                document.createElement(
                    "div"
                );


            card.className =
                "ride-card";


            if (index === 1) {

                card.classList.add(
                    "selected"
                );

            }


            var femaleText =
                parseInt(
                    ride.female_only
                ) === 1

                ? "♀ Female Only"

                : "Open ride";


            card.innerHTML = `

                <h3>
                    ${escapeHTML(
                        ride.driver_name ||
                        "Driver"
                    )}
                </h3>

                <p>
                    ${escapeHTML(
                        ride.from_location
                    )}
                    →
                    ${escapeHTML(
                        ride.to_location
                    )}
                </p>

                <p>
                    ${formatDate(
                        ride.ride_date
                    )}
                    •
                    ${formatTime(
                        ride.ride_time
                    )}
                    •
                    ${escapeHTML(
                        String(
                            ride.available_seats
                        )
                    )}
                    seats
                </p>

                <p>
                    ${femaleText}
                </p>

            `;


            card.style.cursor =
                "pointer";


            card.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "ride_details.html?id="
                        + encodeURIComponent(
                            ride.id
                        );

                }
            );


            container.appendChild(
                card
            );

        }
    );

}



// ==========================================
// DRIVER RIDE CARDS
// ==========================================

function displayDriverRides(
    rides
) {


    var container =
        document.getElementById(
            "rideContainer"
        );


    container.innerHTML = "";


    if (rides.length === 0) {

        var noRide =
            document.createElement(
                "p"
            );


        noRide.innerText =
            "You have no upcoming posted rides.";


        container.appendChild(
            noRide
        );


        return;

    }


    rides.forEach(
        function (ride) {


            var card =
                document.createElement(
                    "div"
                );


            card.className =
                "ride-card";


            var booked =
                parseInt(
                    ride.booked_seats || 0
                );


            var seats =
                parseInt(
                    ride.available_seats || 0
                );


            card.innerHTML = `

                <h3>
                    ${escapeHTML(
                        ride.from_location
                    )}
                    →
                    ${escapeHTML(
                        ride.to_location
                    )}
                </h3>

                <p>
                    📅
                    ${formatDate(
                        ride.ride_date
                    )}
                    •
                    🕐
                    ${formatTime(
                        ride.ride_time
                    )}
                </p>

                <p>
                    ${booked}
                    /
                    ${seats}
                    seats booked
                </p>

                <p>
                    Status:
                    ${escapeHTML(
                        ride.status ||
                        "available"
                    )}
                </p>

            `;


            card.style.cursor =
                "pointer";


            card.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "my_posted_rides.html";

                }
            );


            container.appendChild(
                card
            );

        }
    );

}



// ==========================================
// USER RANK
// ==========================================

function updateRank(
    bookings
) {


    var rank =
        "Bronze";

    var progress =
        25;

    var message =
        "Earn more points to reach Silver";


    if (bookings >= 10) {

        rank =
            "Silver";

        progress =
            55;

        message =
            "Keep going to reach Gold";

    }


    if (bookings >= 25) {

        rank =
            "Gold";

        progress =
            80;

        message =
            "You are close to Platinum";

    }


    if (bookings >= 50) {

        rank =
            "Platinum";

        progress =
            100;

        message =
            "Highest rank reached";

    }


    document.getElementById(
        "userRank"
    ).innerText =
        rank;


    document.getElementById(
        "progressBar"
    ).style.width =
        progress + "%";


    document.getElementById(
        "rankMessage"
    ).innerText =
        message;

}



// ==========================================
// DRIVER RANK
// ==========================================

function updateDriverRank(
    passengers
) {


    var rank =
        "Bronze";

    var progress =
        25;

    var message =
        "Give more rides to reach Silver";


    if (passengers >= 10) {

        rank =
            "Silver";

        progress =
            55;

        message =
            "Keep going to reach Gold";

    }


    if (passengers >= 25) {

        rank =
            "Gold";

        progress =
            80;

        message =
            "You are close to Platinum";

    }


    if (passengers >= 50) {

        rank =
            "Platinum";

        progress =
            100;

        message =
            "Highest rank reached";

    }


    document.getElementById(
        "userRank"
    ).innerText =
        rank;


    document.getElementById(
        "progressBar"
    ).style.width =
        progress + "%";


    document.getElementById(
        "rankMessage"
    ).innerText =
        message;

}



// ==========================================
// GREETING
// ==========================================

function getGreeting() {


    var hour =
        new Date().getHours();


    if (hour < 12) {

        return "Good morning";

    }


    if (hour < 18) {

        return "Good afternoon";

    }


    return "Good evening";

}



// ==========================================
// INITIAL
// ==========================================

function getInitial(
    name
) {


    if (!name) {

        return "S";

    }


    return name
        .trim()
        .charAt(0)
        .toUpperCase();

}



// ==========================================
// FORMAT DATE
// ==========================================

function formatDate(
    dateString
) {


    var date =
        new Date(
            dateString
            + "T00:00:00"
        );


    if (
        isNaN(
            date.getTime()
        )
    ) {

        return dateString;

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short"
        }
    );

}



// ==========================================
// FORMAT TIME
// ==========================================

function formatTime(
    timeString
) {


    if (!timeString) {

        return "";

    }


    var parts =
        timeString.split(":");


    if (parts.length < 2) {

        return timeString;

    }


    var hours =
        parseInt(parts[0]);


    var minutes =
        parts[1];


    var ampm =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {

        hours = 12;

    }


    return (
        hours
        + ":"
        + minutes
        + " "
        + ampm
    );

}



// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHTML(
    value
) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}