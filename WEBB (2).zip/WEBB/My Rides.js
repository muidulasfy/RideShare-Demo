document.addEventListener(
    "DOMContentLoaded",
    function () {

        const bookingList =
            document.querySelector(
                ".booking-list"
            );


        const tabs =
            document.querySelectorAll(
                ".tab"
            );


        let bookings = [];


        let currentTab =
            "upcoming";


        // ==========================================
        // LOAD BOOKINGS
        // ==========================================

        function loadBookings() {

            fetch("My Rides.php")

                .then(function (response) {

                    if (!response.ok) {

                        throw new Error(
                            "Could not load bookings."
                        );

                    }

                    return response.json();

                })

                .then(function (data) {

                    if (!data.success) {

                        bookingList.innerHTML =
                            "<p>" +
                            escapeHTML(
                                data.message
                            ) +
                            "</p>";

                        return;
                    }


                    bookings =
                        Array.isArray(
                            data.bookings
                        )
                            ? data.bookings
                            : [];


                    renderBookings();

                })

                .catch(function (error) {

                    console.error(error);

                    bookingList.innerHTML =
                        "<p>Unable to load your bookings.</p>";

                });

        }


        // ==========================================
        // CHECK IF RIDE IS PAST
        // ==========================================

        function isRidePast(booking) {

            if (
                booking.booking_status ===
                    "completed" ||

                booking.booking_status ===
                    "cancelled"
            ) {

                return true;

            }


            if (
                !booking.ride_date ||
                !booking.ride_time
            ) {

                return false;

            }


            const rideDateTime =
                new Date(
                    booking.ride_date +
                    "T" +
                    booking.ride_time
                );


            return (
                rideDateTime <=
                new Date()
            );

        }


        // ==========================================
        // RENDER BOOKINGS
        // ==========================================

        function renderBookings() {

            const filteredBookings =
                bookings.filter(
                    function (booking) {

                        const past =
                            isRidePast(
                                booking
                            );


                        if (
                            currentTab ===
                            "past"
                        ) {

                            return past;

                        }


                        return !past;

                    }
                );


            // ======================================
            // NO BOOKINGS
            // ======================================

            if (
                filteredBookings.length === 0
            ) {

                if (
                    currentTab ===
                    "upcoming"
                ) {

                    bookingList.innerHTML =
                        `
                        <div class="empty-bookings">
                            <p>
                                No upcoming bookings.
                            </p>
                        </div>
                        `;

                }

                else {

                    bookingList.innerHTML =
                        `
                        <div class="empty-bookings">
                            <p>
                                No past bookings.
                            </p>
                        </div>
                        `;

                }

                return;

            }


            bookingList.innerHTML =
                "";


            // ======================================
            // CREATE EACH BOOKING CARD
            // ======================================

            filteredBookings.forEach(
                function (booking) {

                    const card =
                        document.createElement(
                            "div"
                        );


                    if (
                        booking.booking_status ===
                        "pending"
                    ) {

                        card.className =
                            "booking-card pending-card";

                    }

                    else {

                        card.className =
                            "booking-card";

                    }


                    // ==================================
                    // DATE
                    // ==================================

                    const date =
                        new Date(
                            booking.ride_date +
                            "T00:00:00"
                        );


                    const dateText =
                        date.toLocaleDateString(
                            "en-GB",
                            {
                                day: "2-digit",
                                month: "short"
                            }
                        );


                    // ==================================
                    // TIME
                    // ==================================

                    let timeText =
                        booking.ride_time ||
                        "";


                    if (timeText) {

                        timeText =
                            timeText.substring(
                                0,
                                5
                            );

                    }


                    // ==================================
                    // STATUS
                    // ==================================

                    let status =
                        booking.booking_status ||
                        "";


                    status =
                        status.charAt(0)
                        .toUpperCase() +
                        status.slice(1);


                    // ==================================
                    // SEATS
                    // ==================================

                    const seatsBooked =
                        Number(
                            booking.seats_booked
                        );


                    const seatText =
                        seatsBooked === 1
                            ? "Seat 1"
                            : "Seats " +
                              seatsBooked;


                    // ==================================
                    // TIP
                    // ==================================

                    let tipAmount =
                        Number(
                            booking.tip_amount ||
                            0
                        );


                    if (
                        isNaN(tipAmount) ||
                        tipAmount < 0
                    ) {

                        tipAmount = 0;

                    }


                    const tipText =
                        "৳" +
                        tipAmount.toFixed(2);


                    // ==================================
                    // IS CANCEL BUTTON ALLOWED?
                    // ==================================

                    const ridePast =
                        isRidePast(
                            booking
                        );


                    const canCancel =
                        !ridePast &&
                        booking.booking_status !==
                            "cancelled" &&
                        booking.booking_status !==
                            "completed";


                    // ==================================
                    // CANCEL BUTTON
                    // ==================================

                    let cancelButton =
                        "";


                    if (canCancel) {

                        cancelButton = `
                            <button
                                class="delete-btn"
                                data-booking-id="${Number(
                                    booking.booking_id
                                )}"
                                title="Cancel booking"
                                type="button"
                            >
                                🗑
                            </button>
                        `;

                    }


                    // ==================================
                    // CARD
                    // ==================================

                    card.innerHTML = `

                        <div class="booking-info">

                            <h3>

                                ${escapeHTML(status)}

                                •

                                ${escapeHTML(
                                    booking.driver_name
                                )}

                            </h3>


                            <p>

                                ${escapeHTML(
                                    booking.from_location
                                )}

                                →

                                ${escapeHTML(
                                    booking.to_location
                                )}

                            </p>


                            <p>

                                ${escapeHTML(
                                    dateText
                                )}

                                •

                                ${escapeHTML(
                                    timeText
                                )}

                                •

                                ${escapeHTML(
                                    seatText
                                )}

                            </p>


                            <p class="tip-info">

                                💙 Extra Tip:

                                ${escapeHTML(
                                    tipText
                                )}

                            </p>

                        </div>


                        <div class="booking-actions">

                            ${
                                !ridePast
                                    ? `
                                        <a
                                            href="chat.html?user_id=${Number(
                                                booking.driver_id
                                            )}"
                                            class="message-btn"
                                        >
                                            Message Driver
                                        </a>
                                    `
                                    : ""
                            }


                            ${cancelButton}

                        </div>

                    `;


                    // ==================================
                    // CANCEL BUTTON EVENT
                    // ==================================

                    const deleteButton =
                        card.querySelector(
                            ".delete-btn"
                        );


                    if (deleteButton) {

                        deleteButton.addEventListener(
                            "click",
                            function () {

                                const bookingId =
                                    this.getAttribute(
                                        "data-booking-id"
                                    );


                                const confirmDelete =
                                    confirm(
                                        "Are you sure you want to cancel this booking?"
                                    );


                                if (
                                    !confirmDelete
                                ) {

                                    return;

                                }


                                const formData =
                                    new FormData();


                                formData.append(
                                    "booking_id",
                                    bookingId
                                );


                                this.disabled =
                                    true;


                                fetch(
                                    "cancel_booking.php",
                                    {
                                        method:
                                            "POST",
                                        body:
                                            formData
                                    }
                                )

                                .then(
                                    function (
                                        response
                                    ) {

                                        return response.json();

                                    }
                                )

                                .then(
                                    function (
                                        data
                                    ) {

                                        if (
                                            data.success
                                        ) {

                                            alert(
                                                data.message
                                            );


                                            loadBookings();

                                        }

                                        else {

                                            alert(
                                                data.message
                                            );


                                            deleteButton.disabled =
                                                false;

                                        }

                                    }
                                )

                                .catch(
                                    function (
                                        error
                                    ) {

                                        console.error(
                                            error
                                        );


                                        alert(
                                            "Something went wrong while cancelling the booking."
                                        );


                                        deleteButton.disabled =
                                            false;

                                    }
                                );

                            }
                        );

                    }


                    bookingList.appendChild(
                        card
                    );

                }
            );

        }


        // ==========================================
        // UPCOMING / PAST TABS
        // ==========================================

        tabs.forEach(
            function (
                tab,
                index
            ) {

                tab.addEventListener(
                    "click",
                    function () {


                        tabs.forEach(
                            function (item) {

                                item.classList.remove(
                                    "active"
                                );

                            }
                        );


                        tab.classList.add(
                            "active"
                        );


                        if (
                            index === 0
                        ) {

                            currentTab =
                                "upcoming";

                        }

                        else {

                            currentTab =
                                "past";

                        }


                        renderBookings();

                    }
                );

            }
        );


        // ==========================================
        // ESCAPE HTML
        // ==========================================

        function escapeHTML(value) {

            const div =
                document.createElement(
                    "div"
                );


            div.textContent =
                value === null ||
                value === undefined
                    ? ""
                    : String(value);


            return div.innerHTML;

        }


        // ==========================================
        // START
        // ==========================================

        loadBookings();

    }
);