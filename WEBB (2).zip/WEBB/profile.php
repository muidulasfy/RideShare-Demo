<?php

session_start();

include "db.php";

header("Content-Type: application/json");


// ==========================================
// 1. LOGIN CHECK
// ==========================================

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);

    exit;
}


$user_id =
    intval($_SESSION['user_id']);


// ==========================================
// 2. GET USER
// ==========================================

$userSql = "
    SELECT
        id,
        name,
        email,
        phone,
        department,
        student_id,
        gender,
        role

    FROM users

    WHERE id = ?

    LIMIT 1
";


$userStmt =
    $conn->prepare($userSql);


if (!$userStmt) {

    echo json_encode([
        "success" => false,
        "message" => "Unable to load profile."
    ]);

    exit;
}


$userStmt->bind_param(
    "i",
    $user_id
);


if (!$userStmt->execute()) {

    echo json_encode([
        "success" => false,
        "message" => "Unable to load profile."
    ]);

    $userStmt->close();
    $conn->close();

    exit;
}


$userResult =
    $userStmt->get_result();


if ($userResult->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "message" => "User not found."
    ]);

    $userStmt->close();
    $conn->close();

    exit;
}


$user =
    $userResult->fetch_assoc();


$userStmt->close();


// ==========================================
// 3. BASIC VALUES
// ==========================================

$role =
    strtolower(
        trim(
            $user['role'] ?? ''
        )
    );


// ==========================================
// 4. RESPONSE DATA
// ==========================================

$stats = [

    "stat_one" => 0,

    "stat_two" => 0,

    "average_rating" => null

];


$rides = [];

$driverDetails = null;



// ==================================================
// ==================================================
//                 STUDENT / USER
// ==================================================
// ==================================================

if ($role === "user") {


    // ==========================================
    // AVAILABLE RIDES
    // ==========================================

    $rideSql = "
        SELECT COUNT(*) AS total

        FROM rides

        WHERE status = 'available'

        AND available_seats > 0

        AND TIMESTAMP(
            ride_date,
            ride_time
        ) >= NOW()
    ";


    $rideResult =
        $conn->query($rideSql);


    if ($rideResult) {

        $rideData =
            $rideResult->fetch_assoc();

        $stats["stat_one"] =
            intval($rideData["total"]);

    }



    // ==========================================
    // USER BOOKINGS
    // ==========================================

    $bookingSql = "
        SELECT COUNT(*) AS total

        FROM bookings

        WHERE user_id = ?

        AND booking_status IN
        (
            'pending',
            'confirmed'
        )
    ";


    $bookingStmt =
        $conn->prepare($bookingSql);


    if ($bookingStmt) {

        $bookingStmt->bind_param(
            "i",
            $user_id
        );

        $bookingStmt->execute();

        $bookingResult =
            $bookingStmt->get_result();


        if ($bookingResult) {

            $bookingData =
                $bookingResult->fetch_assoc();

            $stats["stat_two"] =
                intval(
                    $bookingData["total"]
                );

        }


        $bookingStmt->close();

    }



    // ==========================================
    // RECOMMENDED RIDES
    // ==========================================

    $gender =
        strtolower(
            trim(
                $user["gender"] ?? ""
            )
        );


    if ($gender === "female") {

        $recommendedSql = "

            SELECT

                r.id,
                r.from_location,
                r.to_location,
                r.ride_date,
                r.ride_time,
                r.available_seats,
                r.vehicle_type,
                r.female_only,
                r.status,

                u.name AS driver_name

            FROM rides r

            INNER JOIN users u
                ON r.driver_id = u.id

            WHERE r.status = 'available'

            AND r.available_seats > 0

            AND TIMESTAMP(
                r.ride_date,
                r.ride_time
            ) >= NOW()

            ORDER BY
                r.ride_date ASC,
                r.ride_time ASC

            LIMIT 3

        ";

    }

    else {

        $recommendedSql = "

            SELECT

                r.id,
                r.from_location,
                r.to_location,
                r.ride_date,
                r.ride_time,
                r.available_seats,
                r.vehicle_type,
                r.female_only,
                r.status,

                u.name AS driver_name

            FROM rides r

            INNER JOIN users u
                ON r.driver_id = u.id

            WHERE r.status = 'available'

            AND r.available_seats > 0

            AND r.female_only = 0

            AND TIMESTAMP(
                r.ride_date,
                r.ride_time
            ) >= NOW()

            ORDER BY
                r.ride_date ASC,
                r.ride_time ASC

            LIMIT 3

        ";

    }


    $recommendedResult =
        $conn->query(
            $recommendedSql
        );


    if ($recommendedResult) {

        while (
            $row =
            $recommendedResult->fetch_assoc()
        ) {

            $rides[] = $row;

        }

    }

}



// ==================================================
// ==================================================
//                    DRIVER
// ==================================================
// ==================================================

else if ($role === "driver") {


    // ==========================================
    // GET DRIVER DETAILS
    // ==========================================

    $driverSql = "

        SELECT

            license_number,
            vehicle_number,
            vehicle_model

        FROM driver_details

        WHERE user_id = ?

        LIMIT 1

    ";


    $driverStmt =
        $conn->prepare($driverSql);


    if ($driverStmt) {

        $driverStmt->bind_param(
            "i",
            $user_id
        );


        $driverStmt->execute();


        $driverResult =
            $driverStmt->get_result();


        if (
            $driverResult &&
            $driverResult->num_rows > 0
        ) {

            $driverDetails =
                $driverResult->fetch_assoc();

        }


        $driverStmt->close();

    }



    // ==========================================
    // DRIVER'S UPCOMING RIDES
    // ==========================================

    $postedSql = "

        SELECT

            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.status,

            COALESCE(
                SUM(
                    CASE
                        WHEN b.booking_status = 'confirmed'
                        THEN b.seats_booked
                        ELSE 0
                    END
                ),
                0
            ) AS booked_seats

        FROM rides r

        LEFT JOIN bookings b
            ON r.id = b.ride_id

        WHERE r.driver_id = ?

        AND r.status != 'cancelled'

        AND TIMESTAMP(
            r.ride_date,
            r.ride_time
        ) >= NOW()

        GROUP BY

            r.id,
            r.from_location,
            r.to_location,
            r.ride_date,
            r.ride_time,
            r.available_seats,
            r.vehicle_type,
            r.status

        ORDER BY

            r.ride_date ASC,
            r.ride_time ASC

        LIMIT 3

    ";


    $postedStmt =
        $conn->prepare($postedSql);


    if ($postedStmt) {

        $postedStmt->bind_param(
            "i",
            $user_id
        );


        $postedStmt->execute();


        $postedResult =
            $postedStmt->get_result();


        if ($postedResult) {

            while (
                $row =
                $postedResult->fetch_assoc()
            ) {

                $rides[] = $row;

            }

        }


        $postedStmt->close();

    }



    // ==========================================
    // TOTAL POSTED RIDES
    // ==========================================

    $totalRideSql = "

        SELECT COUNT(*) AS total

        FROM rides

        WHERE driver_id = ?

        AND status != 'cancelled'

    ";


    $totalRideStmt =
        $conn->prepare(
            $totalRideSql
        );


    if ($totalRideStmt) {

        $totalRideStmt->bind_param(
            "i",
            $user_id
        );


        $totalRideStmt->execute();


        $totalRideResult =
            $totalRideStmt->get_result();


        if ($totalRideResult) {

            $totalRideData =
                $totalRideResult->fetch_assoc();

            $stats["stat_one"] =
                intval(
                    $totalRideData["total"]
                );

        }


        $totalRideStmt->close();

    }



    // ==========================================
    // TOTAL CONFIRMED PASSENGERS
    // ==========================================

    $passengerSql = "

        SELECT

            COALESCE(
                SUM(b.seats_booked),
                0
            ) AS total

        FROM bookings b

        INNER JOIN rides r
            ON b.ride_id = r.id

        WHERE r.driver_id = ?

        AND b.booking_status = 'confirmed'

    ";


    $passengerStmt =
        $conn->prepare(
            $passengerSql
        );


    if ($passengerStmt) {

        $passengerStmt->bind_param(
            "i",
            $user_id
        );


        $passengerStmt->execute();


        $passengerResult =
            $passengerStmt->get_result();


        if ($passengerResult) {

            $passengerData =
                $passengerResult->fetch_assoc();

            $stats["stat_two"] =
                intval(
                    $passengerData["total"]
                );

        }


        $passengerStmt->close();

    }

}



// ==================================================
// INVALID ROLE
// ==================================================

else {

    echo json_encode([

        "success" => false,

        "message" => "Invalid user role."

    ]);

    $conn->close();

    exit;

}



// ==========================================
// 5. SEND RESPONSE
// ==========================================

echo json_encode([

    "success" => true,

    "user" => [

        "id" =>
            intval($user["id"]),

        "name" =>
            $user["name"],

        "email" =>
            $user["email"],

        "phone" =>
            $user["phone"],

        "department" =>
            $user["department"] ?? "",

        "student_id" =>
            $user["student_id"] ?? "",

        "gender" =>
            $user["gender"] ?? "",

        "role" =>
            $user["role"]

    ],

    "driver" =>
        $driverDetails,

    "stats" =>
        $stats,

    "rides" =>
        $rides

]);


$conn->close();

?>