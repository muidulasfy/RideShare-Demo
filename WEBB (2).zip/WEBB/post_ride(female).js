var gender = localStorage.getItem("gender");


if (
    gender !== "Female" &&
    gender !== "female"
) {

    alert("This page is for female users only");

    window.location.href = "find_ride.html";

}