<?php

session_start();

include "db.php";

header("Content-Type: application/json");


// =========================================
// 1. Login check
// =========================================

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);

    exit;
}


$user_id = intval($_SESSION['user_id']);


// =========================================
// 2. Get current user's gender and role
// =========================================

$userSql = "
    SELECT gender, role
    FROM users
    WHERE id = ?
    LIMIT 1
";

$userStmt = $conn->prepare($userSql);

if (!$userStmt) {

    error_log("Ride details user prepare error: " . $conn->error);

    echo json_encode([
        "success" => false,
        "message" => "Something went wrong."
    ]);

    exit;
}

$userStmt->bind_param("i", $user_id);

$userStmt->execute();

$userResult = $userStmt->get_result();

if ($userResult->num_rows == 0) {

    echo json_encode([
        "success" => false,
        "message" => "User not found."
    ]);

    $userStmt->close();
    $conn->close();

    exit;
}

$user = $userResult->fetch_assoc();

$userGender = strtolower(trim($user['gender'] ?? ""));
$userRole   = strtolower(trim($user['role'] ?? ""));

$userStmt->close();


// =========================================
// 3. Get ride ID
// =========================================

$ride_id = intval($_GET['id'] ?? 0);

if ($ride_id <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid ride ID."
    ]);

    $conn->close();

    exit;
}


// =========================================
// 4. Get ride details
// =========================================

$sql = "
    SELECT
        r.id,
        r.driver_id,
        r.from_location,
        r.to_location,
        r.pickup_checkpoint,
        r.drop_checkpoint,
        r.ride_date,
        r.ride_time,
        r.available_seats,
        r.price_per_seat,
        r.vehicle_type,
        r.female_only,
        r.recurring,
        r.status,

        u.name AS driver_name,
        u.phone AS driver_phone,
        u.gender AS driver_gender

    FROM rides r

    INNER JOIN users u
        ON r.driver_id = u.id

    WHERE r.id = ?
";


$stmt = $conn->prepare($sql);

if (!$stmt) {

    error_log("Ride details prepare error: " . $conn->error);

    echo json_encode([
        "success" => false,
        "message" => "Something went wrong."
    ]);

    $conn->close();

    exit;
}

$stmt->bind_param("i", $ride_id);

$stmt->execute();

$result = $stmt->get_result();


// =========================================
// 5. Ride not found
// =========================================

if ($result->num_rows == 0) {

    echo json_encode([
        "success" => false,
        "message" => "Ride not found."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


$ride = $result->fetch_assoc();


// =========================================
// 6. Female-only protection
// =========================================

if (
    intval($ride['female_only']) === 1 &&
    $userGender !== "female"
) {

    echo json_encode([
        "success" => false,
        "message" => "This ride is available for female passengers only."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =========================================
// 7. Check ride status
// =========================================

if ($ride['status'] !== "available") {

    echo json_encode([
        "success" => false,
        "message" => "This ride is no longer available."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =========================================
// 8. Check available seats
// =========================================

if (intval($ride['available_seats']) <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "No seats are available for this ride."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =========================================
// 9. Check whether ride is in the future
// =========================================

$rideDate = $ride['ride_date'];
$rideTime = $ride['ride_time'];

$currentDate = date("Y-m-d");
$currentTime = date("H:i:s");

if (
    $rideDate < $currentDate ||
    (
        $rideDate === $currentDate &&
        $rideTime <= $currentTime
    )
) {

    echo json_encode([
        "success" => false,
        "message" => "This ride has already passed."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =========================================
// 10. Return ride
// =========================================

echo json_encode([
    "success" => true,
    "ride" => $ride
]);


$stmt->close();

$conn->close();

?>