document.addEventListener("DOMContentLoaded", function () {

    loadMyRides("upcoming");

    setupButtons();

});


// ==========================================
// LOAD MY RIDES
// ==========================================

function loadMyRides(status = "upcoming") {

    const container =
        document.getElementById("ridesContainer");


    container.innerHTML = `
        <div class="loading">
            <div class="loader"></div>
            Loading your rides...
        </div>
    `;


    fetch(
        "my_posted_rides.php?status=" +
        encodeURIComponent(status)
    )

    .then(function (response) {

        return response.json();

    })

    .then(function (data) {

        if (!data.success) {

            container.innerHTML = `
                <div class="no-rides">

                    <div class="empty-icon">⚠️</div>

                    <h3>
                        Unable to load rides
                    </h3>

                    <p>
                        ${escapeHTML(
                            data.message ||
                            "Something went wrong."
                        )}
                    </p>

                </div>
            `;

            return;
        }


        const rides = data.rides || [];


        // ======================================
        // NO RIDES
        // ======================================

        if (rides.length === 0) {

            container.innerHTML = `
                <div class="no-rides">

                    <div class="empty-icon">🚘</div>

                    <h3>
                        No ${escapeHTML(status)} rides
                    </h3>

                    <p>
                        Your ${escapeHTML(status)}
                        posted rides will appear here.
                    </p>

                </div>
            `;

            return;
        }


        container.innerHTML = "";


        // ======================================
        // CREATE CARDS
        // ======================================

        rides.forEach(function (ride, index) {

            const card =
                document.createElement("article");


            card.className = "ride-card";


            card.style.animationDelay =
                (index * 0.08) + "s";


            // ==================================
            // VEHICLE
            // ==================================

            const vehicle =
                String(
                    ride.vehicle_type || ""
                ).toLowerCase();


            let vehicleIcon = "🚗";


            if (
                vehicle.includes("bike") ||
                vehicle.includes("motorcycle")
            ) {

                vehicleIcon = "🏍️";

            }

            else if (
                vehicle.includes("cng") ||
                vehicle.includes("auto")
            ) {

                vehicleIcon = "🛺";

            }

            else if (
                vehicle.includes("hiace") ||
                vehicle.includes("van")
            ) {

                vehicleIcon = "🚐";

            }

            else if (
                vehicle.includes("bus")
            ) {

                vehicleIcon = "🚌";

            }


            // ==================================
            // STATUS
            // ==================================

            let statusText = "Upcoming";

            let statusClass = "upcoming";


            if (status === "completed") {

                statusText = "Completed";

                statusClass = "completed";

            }


            if (status === "cancelled") {

                statusText = "Cancelled";

                statusClass = "cancelled";

            }


            // ==================================
            // SEATS
            // ==================================

            const bookedSeats =
                Number(
                    ride.booked_seats || 0
                );


            const availableSeats =
                Number(
                    ride.available_seats || 0
                );


            const totalSeats =
                bookedSeats + availableSeats;


            // ==================================
            // PRICE
            // ==================================

            const price =
                Number(
                    ride.price_per_seat || 0
                );


            // ==================================
            // FEMALE ONLY
            // ==================================

            const femaleOnly =
                Number(
                    ride.female_only || 0
                );


            // ==================================
            // ACTIONS
            // ==================================

            let actions = "";


            if (status === "upcoming") {

                actions = `

                    <div class="ride-actions">

                        <a
                            href="edit_ride.html?id=${encodeURIComponent(
                                ride.id
                            )}"
                            class="edit-btn"
                        >
                            Edit Ride
                        </a>


                        <button
                            type="button"
                            class="cancel-btn"
                            data-ride-id="${escapeHTML(
                                String(ride.id)
                            )}"
                        >
                            Cancel Ride
                        </button>

                    </div>

                `;

            }

            else {

                actions = `

                    <div class="ride-actions">

                        <span class="no-action">
                            No actions available
                        </span>

                    </div>

                `;

            }


            // ==================================
            // CARD HTML
            // ==================================

            card.innerHTML = `

                <!-- TOP -->

                <div class="ride-top">


                    <div class="route-section">


                        <div class="location-label">

                            <span class="location-dot"></span>

                            ${escapeHTML(
                                ride.from_location || ""
                            )}

                        </div>


                        <div class="route-line"></div>


                        <div class="location-label">

                            <span class="destination-dot"></span>

                            ${escapeHTML(
                                ride.to_location || ""
                            )}

                        </div>


                    </div>


                    <div class="ride-status ${statusClass}">

                        <span></span>

                        ${statusText}

                    </div>


                </div>



                <!-- DETAILS -->

                <div class="ride-middle">


                    <div class="ride-detail">

                        <span class="detail-icon">
                            📅
                        </span>

                        <div>

                            <small>Date</small>

                            <strong>
                                ${escapeHTML(
                                    ride.ride_date || ""
                                )}
                            </strong>

                        </div>

                    </div>



                    <div class="ride-detail">

                        <span class="detail-icon">
                            🕐
                        </span>

                        <div>

                            <small>Time</small>

                            <strong>
                                ${escapeHTML(
                                    formatTime(
                                        ride.ride_time || ""
                                    )
                                )}
                            </strong>

                        </div>

                    </div>



                    <div class="ride-detail">

                        <span class="detail-icon">
                            👥
                        </span>

                        <div>

                            <small>Bookings</small>

                            <strong>
                                ${bookedSeats}/${totalSeats}
                                booked
                            </strong>

                        </div>

                    </div>



                    <div class="ride-detail">

                        <span class="detail-icon price-icon">
                            ৳
                        </span>

                        <div>

                            <small>Price</small>

                            <strong>
                                ৳${price.toFixed(2)}
                                <em>/ seat</em>
                            </strong>

                        </div>

                    </div>


                </div>



                <!-- BOTTOM -->

                <div class="ride-bottom">


                    <div class="ride-tags">


                        ${
                            femaleOnly === 1

                            ? `
                                <span class="tag female-tag">
                                    ♀ Female only
                                </span>
                            `

                            : `
                                <span class="tag normal-tag">
                                    Everyone
                                </span>
                            `
                        }


                        <span class="tag seats-tag">

                            ${availableSeats}

                            ${
                                availableSeats === 1
                                ? " seat"
                                : " seats"
                            }

                            available

                        </span>


                    </div>



                    <div class="vehicle-section">

                        <div class="vehicle-icon">

                            ${vehicleIcon}

                        </div>


                        <span>

                            ${escapeHTML(
                                ride.vehicle_type ||
                                "Vehicle"
                            )}

                        </span>

                    </div>


                    ${actions}


                </div>

            `;


            // ==================================
            // CANCEL BUTTON
            // ==================================

            const cancelButton =
                card.querySelector(
                    ".cancel-btn"
                );


            if (cancelButton) {

                cancelButton.addEventListener(
                    "click",
                    function () {

                        cancelRide(
                            ride.id
                        );

                    }
                );

            }


            container.appendChild(card);

        });

    })


    .catch(function (error) {

        console.error(error);


        container.innerHTML = `

            <div class="no-rides">

                <div class="empty-icon">
                    ⚠️
                </div>

                <h3>
                    Unable to load rides
                </h3>

                <p>
                    Please refresh the page and try again.
                </p>

            </div>

        `;

    });

}



// ==========================================
// SETUP TABS
// ==========================================

function setupButtons() {


    document
        .getElementById("upcomingBtn")
        .addEventListener(
            "click",
            function () {

                setActiveButton(this);

                loadMyRides("upcoming");

            }
        );


    document
        .getElementById("completedBtn")
        .addEventListener(
            "click",
            function () {

                setActiveButton(this);

                loadMyRides("completed");

            }
        );


    document
        .getElementById("cancelledBtn")
        .addEventListener(
            "click",
            function () {

                setActiveButton(this);

                loadMyRides("cancelled");

            }
        );

}



// ==========================================
// ACTIVE TAB
// ==========================================

function setActiveButton(button) {


    document
        .querySelectorAll(
            "#upcomingBtn, #completedBtn, #cancelledBtn"
        )
        .forEach(function (btn) {

            btn.classList.remove("active");

        });


    button.classList.add("active");

}



// ==========================================
// CANCEL RIDE
// ==========================================

function cancelRide(rideId) {


    const confirmed =
        window.confirm(
            "Cancel this ride?\n\n" +
            "All active passenger bookings " +
            "for this ride will also be cancelled."
        );


    if (!confirmed) {

        return;

    }


    const formData =
        new FormData();


    formData.append(
        "ride_id",
        rideId
    );


    fetch(
        "cancel_ride.php",
        {
            method: "POST",
            body: formData
        }
    )

    .then(function (response) {

        return response.json();

    })

    .then(function (data) {


        if (!data.success) {

            showToast(
                data.message ||
                "Ride could not be cancelled.",
                "error"
            );

            return;
        }


        showToast(
            data.message ||
            "Ride cancelled successfully.",
            "success"
        );


        setTimeout(function () {

            loadMyRides("upcoming");

        }, 450);

    })


    .catch(function (error) {

        console.error(error);


        showToast(
            "Something went wrong while cancelling the ride.",
            "error"
        );

    });

}



// ==========================================
// TOAST
// ==========================================

function showToast(
    message,
    type
) {


    const toast =
        document.getElementById("toast");


    toast.textContent = message;


    toast.className =
        "toast show " +
        (type || "");


    setTimeout(function () {

        toast.className = "toast";

    }, 3200);

}



// ==========================================
// FORMAT TIME
// ==========================================

function formatTime(time) {


    if (!time) {

        return "";

    }


    const parts =
        String(time).split(":");


    if (parts.length < 2) {

        return time;

    }


    let hour =
        parseInt(
            parts[0],
            10
        );


    const minute =
        parts[1];


    const suffix =
        hour >= 12
        ? "PM"
        : "AM";


    hour =
        hour % 12;


    if (hour === 0) {

        hour = 12;

    }


    return (
        hour +
        ":" +
        minute +
        " " +
        suffix
    );

}



// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHTML(value) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}